<?php

// Set global constants

// Define your own home url below.
define('HOME_URL', 'https://example.com');