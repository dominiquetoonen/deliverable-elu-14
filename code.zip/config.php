
<?php
define('HOME_URL', 'http://deliverable.local');